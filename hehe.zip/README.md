<h1 align="center"><img src="./assets/Music.gif" width="30px"> Advanced Discord Music Bot <img src="./assets/Music.gif" width="30px"></h1>
<p align="center">Thanks for 4k Views! I made this for you all!</p>
<div align="center"><img src="./assets/banner.gif"></div>

## 📝 Tutorial
Tutorial has been uploaded on YouTube <img src="https://www.youtube.com/about/static/svgs/icons/brand-resources/YouTube_icon_full-color.svg?cache=f2ec7a5" width="30px"> Watch it by clicking [here](https://youtu.be/DQXuTaYa31I)

## 📸 Screenshots

<div align="left"><img src="https://pika-pika.is-inside.me/zJduq9Gn.png"></div><div align="center"><img src="https://pika-pika.is-inside.me/9ufBoGDH.png"></div><div align="right"><img src="https://pika-pika.is-inside.me/8QkGROJv.png"></div>

## 💨 Run the projects
Glitch: [![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/SudhanPlayz/Discord-MusicBot)
Repl: [![Run on Repl.it](https://repl.it/badge/github/SudhanPlayz/Discord-MusicBot)](https://repl.it/github/SudhanPlayz/Discord-MusicBot)
Heroku: [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/SudhanPlayz/Discord-MusicBot)
## ✨ Contributors
Contributions are always welcomed :D
<a href="https://github.com/SudhanPlayz/Discord-MusicBot/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=SudhanPlayz/Discord-MusicBot" />
</a>

Made with :heart: and JavaScript!
